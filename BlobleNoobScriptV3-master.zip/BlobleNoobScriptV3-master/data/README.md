Database files

# Base Library

#### `bases.csv`

It is a csv file containing [LZW](https://en.wikipedia.org/wiki/Lempel%E2%80%93Ziv%E2%80%93Welch) compressed [RSON](https://github.com/ThreeLetters/RSON) data.

#### `bases.png`

It is a png file that visually shows all the bases in the library





