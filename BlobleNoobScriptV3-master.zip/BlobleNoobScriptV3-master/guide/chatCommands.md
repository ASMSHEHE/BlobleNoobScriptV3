# ChatCommands

## Overview

This allows you to enter commands in chat!

Available Commands:

/mute [username|all] - Mutes certain players
/unmute [username|all] - Unmutes certain players
/help - List of commands
/playerlist [page] - List of players
/clear - Clears chat
/toggle - Toggle button UI
/find [username] - Find a user

## Explanation
