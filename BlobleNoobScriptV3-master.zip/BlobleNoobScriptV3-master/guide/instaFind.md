# InstaFind

## Overview

Click on a name on the leaderboard or in chat to instantly find them.

Use the goto(username) function in Developer Console to search by name.

Press the < or > keys to navigate through the search.

You can even use the /find command in chat. Usage:

/find [username]

## Explanation
